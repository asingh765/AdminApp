package com.example.adminapp;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;


public class ProfileFragment extends Fragment {

    private FirebaseAuth mAuth;
    private TextView profileEmail;
    private TextView profileName;
    private TextView profilePhone;
    private TextView profileDob;
    private TextView profileHeaderName;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_profile, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {

        mAuth = FirebaseAuth.getInstance();
        profileEmail = (TextView) getView().findViewById(R.id.profile_email);
        profileDob = (TextView) getView().findViewById(R.id.profile_dob);
        profileName = (TextView) getView().findViewById(R.id.profile_name);
        profilePhone = (TextView) getView().findViewById(R.id.profile_mobile);
        profileHeaderName = (TextView) getView().findViewById(R.id.profile_Header_name);

        if(profileEmail.getText().toString().equals("") || profileName.getText().toString().equals("") || profilePhone.getText().toString().equals("") || profileDob.getText().toString().equals("")){
            getProfileInfo();
        }

        super.onViewCreated(view, savedInstanceState);
    }

    private void getProfileInfo(){
        final String CurrentUserEmail = mAuth.getCurrentUser().getEmail();

        FirebaseDatabase.getInstance().getReference().child("users")
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {
                        for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                            ProfileUser profileuser = snapshot.getValue(ProfileUser.class);
                            System.out.println(profileuser.email);
                            if(profileuser.email.equals(CurrentUserEmail)){
                                profileEmail.setText(profileuser.getEmail());
                                profileDob.setText(profileuser.getDob());
                                profileName.setText(profileuser.getName());
                                profilePhone.setText(profileuser.getPhone());
                                profileHeaderName.setText(profileuser.getName());
                                return ;
                            }
                        }
                    }
                    @Override
                    public void onCancelled(DatabaseError databaseError) {
                    }
                });
    }
}
